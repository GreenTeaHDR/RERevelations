==============================
Resident Evil Revelations

PlayStation DualSense style button prompts v1.00

by GreenTeaZero
https://linktr.ee/GreenTeaZero
==============================

Usage:

Extract 'nativePC' to your Resident Evil Revelations installation folder, overwriting existing files.

If you're using upscaled textures, make sure you add this AFTER placing the textures.


